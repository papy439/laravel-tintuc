<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Test</title>
</head>
<body>
<h2><?php echo e($title); ?></h2>
<div><?php echo e($description); ?></div>
Đây là trang Test
<p><?php echo e($copyright); ?></p>
</body>
</html>