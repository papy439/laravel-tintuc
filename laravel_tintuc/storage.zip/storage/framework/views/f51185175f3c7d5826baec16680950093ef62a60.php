

<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="footer_top">
				<div class="footer_top_left">
					Đăng ký nhận tin tức mới
				</div>
				<div class="footer_top_right">
					<input type="text" placeholder="Email của bạn..." id="txtEmailSub">
					<button id="btnSendSub">SEND</button>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="footer_bottom">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-5 col-md-6">
				<div class="footer_logo">
					<a href="#" title="Trang chủ"><img src="public/images/logo.png" alt="" /></a>
				</div>
			</div>
			<div class="col-xs-12 col-sm-5 col-md-6">
				<div class="footer_copyright">
					Copyright <i class="far fa-copyright"></i>-2021-Project-Nhóm 10.
				</div>
			</div>
		</div>
	</div>
</div>