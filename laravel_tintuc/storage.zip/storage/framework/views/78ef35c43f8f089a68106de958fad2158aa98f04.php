

<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12">
			<div class="footer_top">
				<div class="footer_top_left">
					Đăng ký nhận tin tức mới
				</div>
				<div class="footer_top_right">
					<input type="text" placeholder="Email của bạn..." id="txtEmailSub">
					<button id="btnSendSub">SEND</button>
				</div>
			</div>
		</div>
	</div>
</div>
