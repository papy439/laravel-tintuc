@extends('back.template.master')

@section('title', 'Chào mừng bạn đến trang admin')

@section('heading', 'Chào mừng bạn đến trang quản trị website')

@section('content')


<p>
  <img src="{{url('public/admin/dist/img/admin-animation.gif')}}" alt="Web Admin Animation" style="width: 50%;">
</p>

@stop

