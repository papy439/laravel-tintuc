<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Test</title>
</head>
<body>
<h2>{{ $title }}</h2>
<div>{{ $description }}</div>
Đây là trang Test
<p>{{ $copyright }}</p>
</body>
</html>